package com.example.Hotel.Service.HotelService.services;

import com.example.Hotel.Service.HotelService.entities.Hotel;

import java.util.List;

public interface HotelService {

    //create

    Hotel create(Hotel hotel);

    //getall
    List<Hotel> getAll();

    //getSingle
    Hotel get(String id);

}
