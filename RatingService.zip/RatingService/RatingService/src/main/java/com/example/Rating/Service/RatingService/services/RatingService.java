package com.example.Rating.Service.RatingService.services;

import com.example.Rating.Service.RatingService.entities.Rating;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RatingService {

    //create
    Rating create(Rating rating);

    //get all ratings
    List<Rating> getRating();

    //get all by user id
    List<Rating> getRatingByUserID(String userId);

    //get all by hotel
    List<Rating> getRatingByHotelId(String hotelId);

}
