package com.example.User.Service.UserService.exceptions;

public class ResourceNotFoundExcep extends RuntimeException{

    public ResourceNotFoundExcep()
    {
        super("Resource not found on server");
    }

    public ResourceNotFoundExcep(String message)
    {
           super(message);
    }
}
