package com.example.User.Service.UserService.controllers;

import com.example.User.Service.UserService.entities.User;
import com.example.User.Service.UserService.services.UserService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;
    //create
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user)
    {

        User user1 =  userService.saveUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(user1);
    }

    //single user
    @GetMapping("/{userId}")
    @CircuitBreaker(name = "ratingHotelBreaker",fallbackMethod = "ratingHotelFallback")
    public ResponseEntity<User> getSingleUser(@PathVariable String userId)
    {
        User user = userService.getUser(userId);
        return  ResponseEntity.ok(user);
    }
    //all user

    //creating ratingHotelFallback method for circuit breaker
    public ResponseEntity<User> ratingHotelFallback(String userId, Throwable ex)
    {
        User user=  User.builder()
                .email("asm@gmail.com")
                .name("asm")
                .about("This user name is asm, because some service is down")
                .userId("12345")
                .build();
        return  new ResponseEntity<>(user, HttpStatus.OK);
    }



    @GetMapping
    public ResponseEntity<List<User>> getAllUser()
    {
        List<User> alluser = userService.getAlluser();
        return  ResponseEntity.ok(alluser);
    }

}
