package com.example.User.Service.UserService.exceptions;

import com.example.User.Service.UserService.payload.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundExcep.class)
    public ResponseEntity<ApiResponse> handleResourceNotFoundException(ResourceNotFoundExcep excep)
    {

        String message = excep.getMessage();

         ApiResponse response = ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
            return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);

    }

}
