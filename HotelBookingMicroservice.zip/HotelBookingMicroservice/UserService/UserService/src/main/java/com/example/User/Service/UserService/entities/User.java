package com.example.User.Service.UserService.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.Length;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "micro_users")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User{

    @Id
    @Column(name = "ID")
    private String userId;

    @Column(name = "NAME", length = 20)
    private String name;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "ABOUT")
    private String about;

   /* public void setUserId(String userId) {
        this.userId = userId;
    }*/

    @Transient
    private List<Rating> ratings = new ArrayList<>();

}

