package com.example.User.Service.UserService.services;

import com.example.User.Service.UserService.entities.User;

import java.util.List;

public interface UserService
{
    //operation

    //create
    User saveUser(User user);

    //get all user
    List<User> getAlluser();

    //singleuser by given id
    User getUser(String userId);
}
